package com.gerenciador.dao;

import com.gerenciador.modelo.Produto;
import com.gerenciador.util.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class ProdutoDAO {

    // SALVAR
    public void salvar(Produto produto) {

        Transaction transacao = null;

        try (Session sessao =
                     HibernateUtil.getSessionFactory().openSession()) {

            transacao = sessao.beginTransaction();

            sessao.persist(produto);

            transacao.commit();

        } catch (Exception e) {

            if (transacao != null) {
                transacao.rollback();
            }

            e.printStackTrace();
        }
    }

    // LISTAR
    public List<Produto> listar() {

        try (Session sessao =
                     HibernateUtil.getSessionFactory().openSession()) {

            return sessao
                    .createQuery("FROM Produto", Produto.class)
                    .list();
        }
    }

    // ATUALIZAR
    public void atualizar(Produto produto) {

        Transaction transacao = null;

        try (Session sessao =
                     HibernateUtil.getSessionFactory().openSession()) {

            transacao = sessao.beginTransaction();

            sessao.merge(produto);

            transacao.commit();

        } catch (Exception e) {

            if (transacao != null) {
                transacao.rollback();
            }

            e.printStackTrace();
        }
    }

    // REMOVER
    public void remover(Long id) {

        Transaction transacao = null;

        try (Session sessao =
                     HibernateUtil.getSessionFactory().openSession()) {

            transacao = sessao.beginTransaction();

            Produto produto =
                    sessao.get(Produto.class, id);

            if (produto != null) {

                sessao.remove(produto);
            }

            transacao.commit();

        } catch (Exception e) {

            if (transacao != null) {
                transacao.rollback();
            }

            e.printStackTrace();
        }
    }
}