package com.gerenciador;

import com.gerenciador.dao.ProdutoDAO;
import com.gerenciador.modelo.Produto;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ProdutoDAO dao = new ProdutoDAO();

        int opcao = 0;

        while (opcao != 5) {

            System.out.println("\n===== MENU =====");

            System.out.println("[1] Adicionar Produto");
            System.out.println("[2] Listar Produtos");
            System.out.println("[3] Atualizar Produto");
            System.out.println("[4] Remover Produto");
            System.out.println("[5] Sair");

            System.out.print("Escolha: ");

            opcao = sc.nextInt();

            sc.nextLine();

            switch (opcao) {

                // ADICIONAR
                case 1:

                    Produto p = new Produto();

                    System.out.print("Nome: ");
                    p.setNome(sc.nextLine());

                    System.out.print("Descrição: ");
                    p.setDescricao(sc.nextLine());

                    System.out.print("Preço: ");
                    p.setPreco(sc.nextDouble());

                    System.out.print("Quantidade: ");
                    p.setQuantidade(sc.nextInt());

                    sc.nextLine();

                    System.out.print("Categoria: ");
                    p.setCategoria(sc.nextLine());

                    dao.salvar(p);

                    System.out.println("Produto salvo!");

                    break;

                // LISTAR
                case 2:

                    List<Produto> lista = dao.listar();

                    for (Produto prod : lista) {

                        System.out.println("----------------");

                        System.out.println(
                                "ID: " + prod.getId());

                        System.out.println(
                                "Nome: " + prod.getNome());

                        System.out.println(
                                "Descrição: " + prod.getDescricao());

                        System.out.println(
                                "Preço: " + prod.getPreco());

                        System.out.println(
                                "Quantidade: " + prod.getQuantidade());

                        System.out.println(
                                "Categoria: " + prod.getCategoria());
                    }

                    break;

                // ATUALIZAR
                case 3:

                    Produto atualizar = new Produto();

                    System.out.print("ID do produto: ");
                    atualizar.setId(sc.nextLong());

                    sc.nextLine();

                    System.out.print("Novo nome: ");
                    atualizar.setNome(sc.nextLine());

                    System.out.print("Nova descrição: ");
                    atualizar.setDescricao(sc.nextLine());

                    System.out.print("Novo preço: ");
                    atualizar.setPreco(sc.nextDouble());

                    System.out.print("Nova quantidade: ");
                    atualizar.setQuantidade(sc.nextInt());

                    sc.nextLine();

                    System.out.print("Nova categoria: ");
                    atualizar.setCategoria(sc.nextLine());

                    dao.atualizar(atualizar);

                    System.out.println("Produto atualizado!");

                    break;

                // REMOVER
                case 4:

                    System.out.print("ID do produto: ");

                    Long id = sc.nextLong();

                    dao.remover(id);

                    System.out.println("Produto removido!");

                    break;

                case 5:

                    System.out.println("Encerrando...");

                    break;

                default:

                    System.out.println("Opção inválida!");
            }
        }

        sc.close();
    }
}